package com.machineinteractive.apodktm

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class APODKTMApp : Application()